package dev.tr7zw.exordium.access;

public interface BossEventBufferAccess {
    boolean exordium_needsRender();

    void exordium_captureState();
}
